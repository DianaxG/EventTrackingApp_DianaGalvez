package com.example.eventtrackingapp_dianagalvez;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

// SMS permission imports
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class DashboardActivity extends AppCompatActivity {

    private GridView gridViewEvents;
    private Button buttonAddEvent;
    private DatabaseHelper databaseHelper;
    private String username;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        gridViewEvents = findViewById(R.id.gridViewEvents);
        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        databaseHelper = new DatabaseHelper(this);

        // Get username passed from login
        username = getIntent().getStringExtra("username");

        // Find userId from database
        userId = getUserId(username);

        loadEvents();
        checkSMSPermission(); // <-- Check SMS permission here

        buttonAddEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DashboardActivity.this, AddEventActivity.class);
                intent.putExtra("userId", userId);
                startActivity(intent);
            }
        });

        gridViewEvents.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(DashboardActivity.this, "Click on event to edit (feature coming soon!)", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private int getUserId(String username) {
        Cursor cursor = databaseHelper.getReadableDatabase().rawQuery(
                "SELECT " + DatabaseHelper.COLUMN_USER_ID + " FROM " + DatabaseHelper.TABLE_USERS +
                        " WHERE " + DatabaseHelper.COLUMN_USERNAME + " = ?", new String[]{username});
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(0);
            cursor.close();
            return id;
        } else {
            cursor.close();
            return -1;
        }
    }

    private void loadEvents() {
        Cursor cursor = databaseHelper.getAllEvents(userId);
        ArrayList<String> eventList = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_TITLE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE));
                eventList.add(title + "\n" + date);
            } while (cursor.moveToNext());
        }
        cursor.close();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventList);
        gridViewEvents.setAdapter(adapter);
    }

    // --- NEW CODE BELOW FOR SMS PERMISSION ---
    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        } else {
            Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied. App will continue without SMS notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
