package com.example.eventtrackingapp_dianagalvez;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEventActivity extends AppCompatActivity {

    private EditText editTextTitle, editTextDate, editTextTime, editTextDescription;
    private Button buttonSaveEvent;
    private DatabaseHelper databaseHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        editTextTitle = findViewById(R.id.editTextTitle);
        editTextDate = findViewById(R.id.editTextDate);
        editTextTime = findViewById(R.id.editTextTime);
        editTextDescription = findViewById(R.id.editTextDescription);
        buttonSaveEvent = findViewById(R.id.buttonSaveEvent);

        databaseHelper = new DatabaseHelper(this);

        // Get the userId from the Intent
        userId = getIntent().getIntExtra("userId", -1);

        buttonSaveEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveEvent();
            }
        });
    }

    private void saveEvent() {
        String title = editTextTitle.getText().toString().trim();
        String date = editTextDate.getText().toString().trim();
        String time = editTextTime.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();

        if (title.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean inserted = databaseHelper.addEvent(title, date, time, description, userId);

        if (inserted) {
            Toast.makeText(this, "Event saved successfully!", Toast.LENGTH_SHORT).show();
            finish(); // Go back to Dashboard
        } else {
            Toast.makeText(this, "Failed to save event.", Toast.LENGTH_SHORT).show();
        }
    }
}
